function changeColor(x,y){
      x.style.backgroundColor = y;}