/*----------------------------------------------------------------------
pca.c - principal component analysis with missing data support
by Andy Allinger, 2017, released to the public domain
This program may be used by any person for any purpose.
----------------------------------------------------------------------*/
#include <stdbool.h>
#include <math.h>
#include <float.h>

void add (float *, int, float *); /* defined in add.c */
int seigv (float **, int, float *, float **, float *); /* defined in eigen.c */
void median (float *, int, float *); /* defined in median.c */
bool safdiv (float, float); /* defined in cluela.c */

/*----------------------------------------------------------------------
PCA - Principal Component Analysis

___Name_______Type______In/Out____Description___________________________
   x[n][p]    float**   In        Data matrix
   nx[n][p]   int**     In        1 if data exists this point, 0 otherwise
   n          int       In        Number of objects
   p          int       In        Variables each object
   w[p]       float*    In        Importance weight each variable
   a[p]       float*    Out       Averages each variable
   e[p]       float*    Out       Eigenvalues of covariance matrix
   v[p][p]    float**   Out       Eigenvectors of covariance matrix
   t[p]       float*    Neither   Workspace
   u[n]       float*    Neither   Workspace
   r[n][m]    float**   Out       Projected data
   m          int       In        # of dimensions to project
   level      int       In        Level of robustness:
       -1 => flimsy statistics, Chebyshev codeviation
        0 => regular statistics, covariance matrix
        1 => semi-robust statistics, Manahattan codeviation
        2 => robust statistics, comedian matrix
----------------------------------------------------------------------*/
int pca (float **x, int **nx, int n, int p, float *w, float *a, float *e,
         float **v, float *t, float *u, float **r, int m, int level)
{
/* Local variables */
	int h, i, j, k, ifault;
	float xj, xk;
	float xdif, vall, rtot, vtot, xsum;
/* Function Body */
	if (m > p) return -1;
	if (level < -1 || level > 2) return -2;

/*----------------------------------------------------------------------
   Compute averages.
----------------------------------------------------------------------*/
	for (j = 0; j < p; ++j) {
		h = 0;
		for (i = 0; i < n; ++i) {
			if (nx[i][j] > 0) {
				u[h] = x[i][j];
				++h;
			}
		}
		if (h > 0) {
			if (0 == level) {
				add (u, h, &rtot);
				a[j] = rtot / (float) h;
			} else if (-1 == level) {
				xj = u[0];
				xk = u[0];
				for (i = 1; i < h; ++i) {
					xj = fminf(xj, u[i]);
					xk = fmaxf(xk, u[i]);
				}
				a[j] = (xj + xk) * .5f;
			} else {
				median (u, h, &a[j]);
			}
		} else {
			a[j] = 0.f;
		}
	}

/*----------------------------------------------------------------------
Overall codeviation / covariance matrix.
A criterion for the orthogonality of two vectors u and v is that
the distance from u to v should equal the distance from u to -v.

Applying the Linfinity metric, this means that
  max|u - v| = max|u - (-v)|
  (1/2) (max|u + v| - max|u - v|) = 0

Applying the L2 metric, this means that
  sum(u - v)^2 = sum(u - (-v))^2
  sum(uv) = 0

Applying the L1 metric, this means that
  sum|u - v| = sum|u - (-v)|
  (1/2) sum(|u + v| - |u - v|) = 0

which is identical to the expression
  max(min(u, v), min(-u, -v))

Thus, the L2 orthogonality criterion yields the formula for covariance,
and the L1 orthogonality criterion yields the formula for codeviation.
For more information on applications of L1 orthogonality, request the
technical report "A direct method for L1-norm codeviation" [2013] from
  andy@13olive.net

The comedian matrix is a highly robust estimate of covariance
that is easy to compute.  Refer to:
     Michael Falk
     "On MAD and Comedians"
     Ann. Inst. Statist. Math., v.49 n.4 pp.615-644, 1997

The Linfinity codeviation matrix generalizes the range.
The covariance matrix generalizes the variance.
The L1 codeviation matrix generalizes the mean absolute deviation.
The comedian matrix generalizes the median absolute deviation.

It should be acknowledged that there are many ways to handle the missing
data problem, many robust variants of the covariance matrix have been
proposed, and there are many ways to approximately factor a matrix.
----------------------------------------------------------------------*/
	for (k = 0; k < p; ++k) {
		for (j = k; j < p; ++j) {
			xsum = 0.f;
			xdif = 0.f;
			h = 0;
			for (i = 0; i < n; ++i) {
				if (nx[i][j] > 0 && nx[i][k] > 0) {
					xj = (x[i][j] - a[j]) * w[j];
					xk = (x[i][k] - a[k]) * w[k];
					if (-1 == level) {
						xsum = fmaxf(xsum, fabsf(xj + xk));
						xdif = fmaxf(xdif, fabsf(xj - xk));
					} else if (0 == level || 2 == level) {
						u[h] = xj * xk;
					} else {
						u[h] = fmaxf(fminf(xj, xk), fminf(-xj, -xk));
					}
					++h;
				}
			}
			if (-1 == level) {
				v[j][k] = (xsum - xdif) * .5f;
			} else if (0 == level || 1 == level) {
				if (h > 1) {
					add (u, h, &rtot);
					v[j][k] = rtot / (float) (h - 1);
				} else {
					v[j][k] = 0.f;
				}
			} else {
				if (h > 0) {
					median (u, h, &v[j][k]);
				} else {
					v[j][k] = 0.f;
				}
			}
		}
	}

/*----------------------------------------------------------------------
         Factor covariance matrix
----------------------------------------------------------------------*/
	ifault = seigv (v, p, e, v, t);
	if (ifault != 0) return ifault;

/*----------------------------------------------------------------------
The singular value decomposition is X = U S V^T
The symmetric eigenproblem is X^T X = V L V^T
Step through columns of V in reverse order so that the first column
of R has the greatest variance.
----------------------------------------------------------------------*/
/* R[i,k] = X[j,i] V[j,p-k+1] */
	for (k = 0; k < m; ++k) {
		for (j = 0; j < p; ++j) t[j] = v[j][p-k-1] * w[j];
		add (t, p, &vall);
		for (i = 0; i < n; ++i) {
			rtot = 0.f;
			vtot = 0.f;
			for (j = 0; j < p; ++j) {
				if (nx[i][j] > 0) {
					rtot += (x[i][j] - a[j]) * t[j];
					vtot += t[j];
				}
			}
			r[i][k] = safdiv(vall, vtot) ? rtot * (vall / vtot) : 0.f;
		}
	}
	return 0;
} /* end of pca */

/*----------------------------------------------------------------------
 DIVEV - divide by the square roots of the eigenvalues to obtain the
matrix U of X = U S V^T

___Name______Type______In/Out___Description_____________________________
   r[n][m]   float**   Both     Projected data
   n         int       In       Size of data set
   m         int       In       # of dimensions to project
   e[p]      float*    In       Eigenvalues
   p         int       In       Variables each observation
----------------------------------------------------------------------*/
void divev (float **r, int n, int m, float *e, int p)
{
/* Local variables */
	int i, j, k;
	float tol, fact;
/* Function Body */
	tol = p * FLT_EPSILON;
	for (j = 0; j < m; ++j) {
		k = p - j - 1;
		fact = (e[k] > tol) ? (1.f / sqrtf(e[k]) / (float) (n - 1)) : 0.f;
		for (i = 0; i < n; ++i) r[i][j] *= fact;
	}
	return;
} /* end of divev */
