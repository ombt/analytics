/*----------------------------------------------------------------------
Data fusion of ragtime performances by method of data clustering
by Andy Allinger, 2016-2017, public domain
This program may be used by any person for any purpose.
----------------------------------------------------------------------*/
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

int kmns (float **a, int m, int n, float **c, int k, /* defined in kmns.c */
          int *ic1, int *ic2, int *nc, float *an1, float *an2,
	     int *ncp, float *d, int *itran, int *live, int iter, float *wss);
int **new_int_mtx (int, int); /* defined in array.c */
float **new_flt_mtx (int, int);
char **new_ch_mtx (int, int);
int del_int_mtx (int **, int);
int del_flt_mtx (float **, int);
int del_ch_mtx (char **, int);
int ireid (char **h, int *id, int *nx, int *ind, int *jnd, int n, int h_len, char *hwork);
int rscode (float **x, int **nx, int n, int p, float *w,
            int *cat, int o, float **s, int catmax, bool robust);
void shuffl (int *i, int n); /* defined in cluela.c */
void dinit (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
           int k, bool robust, float *shortx, float *cumd, float *thresh);
int kclust (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
            int kmin, int *k, int kmax, int *z, int *pop, bool miss, bool robust, bool sosdo,
            float thresh, int *livec, int *livex, int *iperm, int **tree,
            float *shortc, float *shortx, float *work, float *u);
int cluela (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
            int kmin, int *k, int kmax, int *z, int *pop, float *f, bool robust,
            bool sosdo, int *iwork, float *rwork, int **tree, float *u);
int cluste (float **x, int **nx, int n, int p, float *w, float **c, int **nc, /* defined in cluste.c */
            int kmin, int *k, int kmax, int *z, int *pop, bool robust,
            bool sosdo, int *iwork, float *rwork, int **tree, float *u);
int neugas (float **, int, int, float **, int, int *, float *); /* defined in neugas.c */
float arind (int *y, int *z, int n, int g, int k, float **m, float *a, float *b); /* defined in valid.c */
float vinfo (int *y, int *z, int n, int g, int k, float **m, float *a, float *b);
int pca (float **x, int **nx, int n, int p, float *w, float *a, float *e, /* defined in pca.c */
         float **v, float *t, float *u, float **r, int m, int level);
int wcsvsp (float **, int, int *, FILE *); /* defined in dump.c */

int main (void)
{
/* Constants */
#define CATMAX 5   /* most categories any attribute */
#define FNLEN 32   /* length of a file name */
#define G 975      /* # correct classes */
#define HLEN 4     /* length of class labels */
#define KDEF 975   /* # clusters for KMNS */
#define KMIN 974   /* fewest clusters to make */
#define KMAX 978   /* most clusters to make */
#define KNG 200    /* # clusters for neural gas */
#define M 2        /* dimensions to embed into */
#define N 4382     /* number of objects */
#define NS 12      /* node size of binary tree */
#define O 7        /* input attributes */
#define P 10       /* attributes after encoding */
#define TXTLEN 256 /* length of line of input file */

	const int iter = 1000,     /* max iterations for KMNS */
	    kcmin = 900,           /* fewer clusters for KCLUST */
	    level = 0;             /* robustness level for PCA */
	const float BIG = 1.e36f;  /*  arbitrary large number */
	const bool robust = false; /* Use L1 metric ? */

/* Local variables */
	int h, i, j, k, l,
	  y[N], z[N], ferr, kbest, iperm[N], jperm[N], zbest[N], jng[KNG],
	  iwork[4*N+KMAX], nx0[N], pop[KMAX], yfake[N], ifault;
	float a[P], e[P], f[KMAX-KMIN+1], t[P], u, an1[KDEF], an2[KDEF],
	  fid, dng[KNG], aval[G], bval[KMAX], wss[KDEF], accvi, ubest, tf,
	  rwork[2*N+KMAX], accari, thresh;
	bool sosdo, ok;
	char hwork[HLEN], text[TXTLEN];
	char *sptr;
	FILE *iou;

/* Allocate arrays */
	int **nx, **nc, **tree;
	float **c, **r, **s, **x, **xw, **v, **cng, **mval, **emb;
	char **label;
	nx = new_int_mtx(N, P);
	nc = new_int_mtx(KMAX, P);
	tree = new_int_mtx(2*KMAX, NS);
	c = new_flt_mtx(KMAX, P);
	r = new_flt_mtx(N, M);
	s = new_flt_mtx(CATMAX, CATMAX-1);
	x = new_flt_mtx(N, P);
	xw = new_flt_mtx(N, P);
	v = new_flt_mtx(P, P);
	mval =new_flt_mtx(G, KMAX);
	emb = new_flt_mtx(KNG, M);
	cng = new_flt_mtx(KNG, P);
	label = new_ch_mtx(N, HLEN);
	if (!nx || !nc || !tree || !c || !r || !s || !x || !xw || !v || !mval
	  || !emb || !cng | !label) goto L90;

	static char fname[FNLEN] = "maple.data";
/*----------------------------------------------------------------------
The Maple Leaf corpus is five performances of the Maple Leaf Rag of
Scott Joplin, Bill Flynt, Gary Rogers, Alessandro Simonetto,
and Mario Verehrer.  Each performed note was either matched to a note
in the score, or else marked as stray.

___Attribute________Type_________________#___Values____________________
   index fraction   Continuous               0...1
   onset time       Continuous               [seconds]
   tactus phase     Cyclic                   [beats]
   channel          Categorical          1   1
   source file      Contra-categorical   5   1, 2, 3, 4, 5
   pitch            Continuous               0...127
   velocity         Continuous               0...127
   duration         Continuous               [seconds]

-----------------------------------------------------------------------
Phase is a cyclic variable, because the phase difference
from 0.95 beats to 0.05 beats is 0.1, not 0.9.  No provision has been
made in package CLUELA to deal with cyclic data, and this error will
have to be tolerated.

Categorical variable channel does not vary.  Categorical variables with
only one category are not allowed.  It could be coded as continuous,
but it makes more sense to omit it.

The source file is contra-categorical.  That is, separate events that
come from the same performance should be LESS likely to correspond to
the same ideal note.  The effects of including such a variable will be
studied.

Because musical pitch wraps on the octaves and on the circle of fifths,
pitch could be included again as a cyclic variable, if that feature
were implemented.
----------------------------------------------------------------------*/

/* Description of data */
	int cat[O] = { 0,0,0,5,0,0,0 };
	float w[P] = { 7154.676f, 129.92297f, .52602184f, 0.f, 6.560541f,
	  3.9798368e-4f, 14.043207f, 0.f, 0.f, 0.f };
/* Initial values */
	for (i = 0; i < N; ++i) yfake[i] = 1;
	for (i = 0; i < N; ++i) nx0[i] = 1;
	for (i = 0; i < N; ++i) {
		for (j = 0; j < P; ++j) {
			nx[i][j] = 1;
		}
	}
	srand( (unsigned int)time(NULL));

/*----------------------------------------------------------------------
Read in data, discard the headers.  Keep the first three entries,
discard the fourth, keep the fifth thru eighth as columns 3...6 of array X,
then read the class label as a four-character string.
----------------------------------------------------------------------*/
	iou = fopen(fname, "r");
	if (NULL == iou) printf("trouble opening input file!\n");
	sptr = fgets(text, TXTLEN, iou); /* burn header line */
	if (NULL == sptr) printf("tmaple: trouble reading data file header.\n");
	for (i = 0; i < N; ++i) {
		sptr = fgets(text, TXTLEN, iou);
		if (NULL == sptr) printf("tmaple: trouble reading line %d\n", i);
		sptr = strtok(text, ",");
		if (NULL == sptr) printf("nothing to read! line %d\n", i);
		ferr = sscanf(sptr, "%f", &x[i][0]);
		if (0 == ferr) printf("tmaple: trouble scanning line %d\n", i);
		for (j = 1; j < 3; ++j) {
			sptr = strtok(NULL, ",");
			if (NULL == sptr) printf("nothing to read! line %d item %d\n", i, j);
			ferr = sscanf(sptr, "%f", &x[i][j]);
			if (0 == ferr) printf("tmaple: trouble scanning line %d entry %d \n", i, j);
		}
		sptr = strtok(NULL, ","); /* burn fourth field */
		for (j = 3; j < O; ++j) {
			sptr = strtok(NULL, ",");
			if (NULL == sptr) printf("nothing to read! line %d item %d\n", i, j);
			ferr = sscanf(sptr, "%f", &x[i][j]);
			if (0 == ferr) printf("tmaple: trouble scanning line %d entry %d\n", i, j);
		}
		sptr = strtok(NULL, ",");
		if (NULL == sptr) printf("nothing to read! line %d, class label\n", i);
		strncpy(label[i], sptr, HLEN);
	}
	ferr = fclose(iou);
	if (0 != ferr) printf("tmaple: trouble closing file %s\n", fname);
/* preprocess input */
	fid = 0.f; /* change onset times so that all files are the same duration */
	tf = 50.f;
	for (i = N-1; i >= 0; --i) {
		if (fabsf(x[i][3] - fid) > .5f) tf = x[i][1]; /* begin another file */
		x[i][1] *= 50.f / tf;
		fid = x[i][3];
	}
	ifault = rscode (x, nx, N, P, w, cat, O, s, CATMAX, robust);
	if (0 != ifault) printf("rscode: error #%d\n", ifault);
/* recode classes as consecutive integers */
	ifault = ireid (label, y, nx0, iperm, jperm, N, HLEN, hwork);
	if (0 != ifault) printf("ireid: error #%d\n", ifault);
/* call the subroutine */
	k = G;
	sosdo = true;
	ifault = cluela (x, nx, N, P, w, c, nc, KMIN, &k, KMAX,
	  z, pop, f, robust, sosdo, iwork, rwork, tree, &u);
	printf("cluela returns #%d, made %d clusters.\n", ifault, k);
/* find accuracy */
	if (0 == ifault) {
		accari = arind (y, z, N, G, k, mval, aval, bval); /* adjusted Rand index */
		accvi = vinfo (y, z, N, G, k, mval, aval, bval); /* variation of information */
		printf("returned residual:  %f, Adjusted Rand Index:  %f, Variation of Information:  %f\n",
		  u, accari, accvi);
	}
/* Call CLUSTE instead */
	ubest = BIG;
	kbest = G;
	ok = false;
	for (h = 0; h < 10; ++h) {
		k = G;
		sosdo = false;
		ifault = cluste (x, nx, N, P, w, c, nc, kcmin, &k, KMAX,
		  z, pop, robust, sosdo, iwork, rwork, tree, &u);
		if (0 == ifault) {
			ok = true;
			if (u < ubest) {
				ubest = u;
				kbest = k;
				for (i = 0; i < N; ++i) zbest[i] = z[i];
			}
		} else {
			printf("cluste: error#%d\n", ifault);
		}
	}
	printf("cluste returns #%d, made %d clusters.\n", ifault, kbest);
/* find accuracy */
	if (ok) {
		accari = arind (y, zbest, N, G, kbest, mval, aval, bval);
		accvi = vinfo (y, zbest, N, G, kbest, mval, aval, bval);
		printf("returned residual:  %f, Adjusted Rand Index:  %f, Variation of Information:  %f\n",
		  ubest, accari, accvi);
	}
/* compare against KMNS */
	for (i = 0; i < N; ++i) { /* multiply in weights */
		for (j = 0; j < P; ++j) {
			xw[i][j] = x[i][j] * sqrtf(w[j]);
		}
	}
	ubest = BIG;
	k = KDEF;
	ok = false;
	for (h = 0; h < 10; ++h) {
		dinit (x, nx, N, P, w, c, nc, k, robust, rwork, &rwork[N], &thresh);
		for (l = 0; l < k; ++l) { /* scale centers */
			for (j = 0; j < P; ++j) {
				c[l][j] *= sqrtf(w[j]);
			}
		}
		ifault = kmns (xw, N, P, c, k, z, iperm, pop, an1, an2, iwork,
		  rwork, &iwork[k], &iwork[k*2], iter, wss);
		if (0 == ifault) {
			u = 0.f;
			ok = true;
/* combine per-cluster residuals */
			for (l = 0; l < k; ++l) u += wss[l];
			if (u < ubest) {
				ubest = u;
				for (i = 0; i < N; ++i) zbest[i] = z[i];
			}
		} else {
			printf("kmns: error#%d\n", ifault);
		}
	}
	printf("kmns returns #%d, made %d clusters.\n", ifault, k);
/* find accuracy */
	if (ok) {
		accari = arind (y, zbest, N, G, k, mval, aval, bval);
		accvi = vinfo (y, zbest, N, G, k, mval, aval, bval);
		printf("returned residual:  %f, Adjusted Rand Index:  %f, Variation of Information:  %f\n",
		  ubest, accari, accvi);
	}
/* Compare against neural gas */
	shuffl (iwork, N);
	for (l = 0; l < KNG; ++l) {
		i = iwork[l];
		for (j = 0; j < P; ++j) cng[l][j] = x[i][j];
	}
	neugas (x, N, P, cng, KNG, jng, dng);
	printf("neugas returns\n");
/* Write CSV file */
	ifault = pca (x, nx, N, P, w, a, e, v, t, rwork, r, M, level); /* project to 2-D */
	if (0 != ifault) printf("pca: error#%d\n", ifault);
	strncpy(fname, "maple_plot.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("tmapl: trouble opening %s\n", fname);
	ifault = wcsvsp(r, N, yfake, iou);
	if (0 != ifault) printf("wcsvsp: error#%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("tmaple: trouble closing %s\n", fname);
/* write F values */
	strncpy(fname, "maple_fvals.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("tmapl: trouble opening %s\n", fname);
	for (l = KMIN; l <= KMAX; ++l) {
		ifault = fprintf(iou, "%5d, %9.3g\n", l, f[l-KMIN]);
		if (0 == ifault) printf("tmapl: trouble writing F stats\n");
	}
	ferr = fclose(iou);
	if (0 != ferr) printf("tmaple: trouble closing %s\n", fname);
/* Embed the Neural Gas centers into projected coordinates */
	for (k = 0; k < M; ++k) {
		for (j = 0; j < P; ++j) {
			t[j] = v[j][P-k-1] * w[j];
		}
		for (l = 0; l < KNG; ++l) {
			emb[l][k] = 0.f;
			for (j = 0; j < P; ++j) emb[l][k] += (cng[l][j] - a[j]) * t[j];
		}
	}
	strncpy(fname, "maple_ng_centers.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("mapl: trouble opening %s\n", fname);
	ifault = wcsvsp (emb, KNG, yfake, iou);
	if (0 != ifault) printf("wcsvsp: error#%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("tmapl: trouble closing %s\n", fname);
L90: /* clean up */
	if (nx) del_int_mtx(nx, N);
	if (nc) del_int_mtx(nc, KMAX);
	if (tree) del_int_mtx(tree, 2*KMAX);
	if (c) del_flt_mtx(c, KMAX);
	if (r) del_flt_mtx(r, N);
	if (s) del_flt_mtx(s, CATMAX);
	if (x) del_flt_mtx(x, N);
	if (xw) del_flt_mtx(xw, N);
	if (v) del_flt_mtx(v, P);
	if (mval) del_flt_mtx(mval, G);
	if (emb) del_flt_mtx(emb, KNG);
	if (cng) del_flt_mtx(cng, KNG);
	if (label) del_ch_mtx(label, N);
return 0;
} /* end of main */
