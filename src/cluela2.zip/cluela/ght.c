/*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
ght.c - a generalized hyperplane tree for the k-means problem
by Andy Allinger, 2013-2017, released to the public domain
This program may be used by any person for any purpose.

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
  The generalized hyperplane tree organizes a data set by partitioning,
like any binary tree.  Unlike the k-d tree, there is no requirement for
the data to be represented in R^N Euclidean space.  A data set which has
a dissimilarity between each datum may be split by choosing two points,
and assigning the remaining points to a partition by whether they are
nearer the first point or the second point.  If the data and dissimilarity
function satisfy the requirements of a metric space, then the triangle
inequality may be used to efficiently search the tree for nearest
neighbors of a point.

Early research was:
    I. Kalantari and G. McDonald
    "A data structure and an algorithm for the nearest point problem"
    IEEE Transactions on Software Engineering, v.9 p.5, 1983

cited in:
    Edgar Chavez, Gonzallo Navarro, and Jose Luis Marroquin
    "Searching in Metric Spaces"
    Association for Computing Machinery, 1999

It was discussed also in:
    Jeffrey K. Uhlmann
    "Satisfying General Proximity/Similarity Queries with Metric Trees"
    Information Processing Letters, v.40 pp.175-179, November 1991

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    Suppose the pivots are O and P, a query point is Q.  There may be
a hypothetical point S near the boundary surface.  The distance QS must
be bounded to compare it to r, the radius of the ball containing the known
neighbors of Q.  Construct triangle PQS, then by the triangle inequality:
      QS + PS .GE. PQ             =>      QS .GE. PQ - PS
Construct triangle OQS, then
      QS + OQ .GE. OS             =>      QS .GE. OS - OQ
Add
                         2 @ QS .GE. (PQ - OQ) + (OS - PS)
OS = PS by definition, so
                             QS .GE. (PQ - OQ) / 2
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/
#include <stdbool.h>
#include <math.h>

/*----------------------------------------------------------------------
GHTDSM - a dissimilarity function

___Name_____Type_____In/Out___Description_______________________________
   a[p]     float*   In       Data vector
   b[p]     float*   In       Data vector
   p        int      In       Dimension of the data
   w[p]     float*   In       Importance weights
   robust   bool     In       Use robust statistics
   best     float    In       Bail out if this value is exceeded
   ghtdsm   float    Out      Manhattan distance or squared Euclidean
----------------------------------------------------------------------*/
float ghtdsm (float *a, float *b, int p, float *w, bool robust, float best)
{
/* Local variables */
	int j;
	float r, retval;
/* Function Body */
	retval = 0.f;
	if (robust) { /* Manhattan */
		for (j = 0; j < p; ++j) {
			retval += w[j] * fabsf(a[j] - b[j]);
			if (retval > best) return retval;
		}
	} else { /* squared Euclidean */
		for (j = 0; j < p; ++j) {
			r = a[j] - b[j];
			retval += w[j] * (r * r);
			if (retval > best) return retval;
		}
	}
	return retval;
} /* end of ghtdsm */

/*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
GHTINI - initialize a generalized hyperplane tree

___Name___________Type_____I/O_____Description__________________________
  tree[2*k][12]   int**    Both    The generalized hyperplane tree
  last            int      Out     Last filled index in tree
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/
void ghtini (int **tree, int *last)
{
/* Constants */
	enum {STEM, LEAF, BUCK0, BUCK9 = 11};
/* local variables */
	int j;
/* Function Body */
	*last = 0;
	tree[*last][STEM] = -1;
	tree[*last][LEAF] = -1;
	for (j = BUCK0; j <= BUCK9; ++j) tree[*last][j] = -1;
	return;
} /* end of ghtini */

/*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
GHTINS - insert a cluster center into a generalized hyperplane tree

___Name____________Type______I/O____Description_________________________
   p               int       In     # variables each datum
   w[p]            float*    In     Importance weights
   c[k][p]         float**   In     Center data
   k               int       In     # of clusters
   robust          bool      In     Use Manhattan distance
   q               int       In     Index into C of a center to insert
   tree[2*k][12]   int**     Both   The generalized hyperplane tree
   last            int*      Both   Last filled index in tree
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/
void ghtins (int p, float *w, float **c, int k, bool robust, int q,
             int **tree, int *last)
{
/* Constants */
	enum {POINTS, POINTL, POINTR, PIVOTL, PIVOTR,
	      LEAF = 1, BUCK0 = 2, BUCK9 = 11};
	static float BIG = 1.e36f;
/* Local variables */
	int g, h, i, j, l;
	int nl, pl, nr, pr;
	float d, dl, dr, dfar;
/* Function Body */
	l = 0; /* the root node */
L10:
	if (-1 == tree[l][LEAF]) { /* leaf node? */
		for (h = BUCK0; h <= BUCK9; ++h) {
			if (-1 == tree[l][h]) { /* space remaining in node? */
				tree[l][h] = q; /* insert the point */
				return;
			}
		}
		goto L50; /* node is full, so split */
	}
/* measure */
	pl = tree[l][PIVOTL];
	pr = tree[l][PIVOTR];
	dl = ghtdsm (c[pl], c[q], p, w, robust, BIG);
	dr = ghtdsm (c[pr], c[q], p, w, robust, dl);
	if (dl < dr) { /* climb left branch */
		l = tree[l][POINTL];
	} else if (dr < dl) { /* climb right branch */
		l = tree[l][POINTR];
	} else { /* equality */
		if (q % 2) {
			l = tree[l][POINTL];
		} else {
			l = tree[l][POINTR];
		}
	}
	goto L10;

/*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    Split existing node, create two branch nodes.
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/
L50:
	dfar = -BIG; /* find longest distance between points in bucket */
	pl = tree[l][BUCK0]; /* avoid uninitialized warning */
	pr = tree[l][BUCK9];
	for (j = BUCK0; j <= BUCK9-1; ++j) {
		nr = tree[l][j];
		for (i = j+1; i <= BUCK9; ++i) {
			nl = tree[l][i];
			d = ghtdsm (c[nl], c[nr], p, w, robust, BIG);
			if (d > dfar) {
				dfar = d;
				pl = nl;
				pr = nr;
			}
		}
	}
/* make new nodes */
	++(*last);
	nl = *last;
	tree[nl][POINTS] = l;
	tree[nl][LEAF] = -1;
	for (h = BUCK0; h <= BUCK9; ++h) tree[nl][h] = -1;
	++(*last);
	nr = *last;
	tree[nr][POINTS] = l;
	tree[nr][LEAF] = -1;
	for (h = BUCK0; h <= BUCK9; ++h) tree[nr][h] = -1;
/* sort */
	i = BUCK0;
	j = BUCK0;
	for (h = BUCK0; h <= BUCK9; ++h) {
		g = tree[l][h];
/* Null objects may have a positive self distance.
   Force a pivot datum into the node it anchors. */
		dl = (g == pl) ? -1.f : ghtdsm (c[g], c[pl], p, w, robust, BIG);
		dr = (g == pr) ? -1.f : ghtdsm (c[g], c[pr], p, w, robust, dl);
		if (dl < dr) { /* copy datum to left branch */
			tree[nl][i] = tree[l][h];
			++i;
		} else if (dr < dl) { /* copy datum to right branch */
			tree[nr][j] = tree[l][h];
			++j;
		} else { /* equality */
			if (h % 2) {
				tree[nl][i] = tree[l][h];
				++i;
			} else {
				tree[nr][j] = tree[l][h];
				++j;
			}
		}
	}
/* Current node becomes a stem node */
	tree[l][POINTL] = nl;
	tree[l][POINTR] = nr;
	tree[l][PIVOTL] = pl;
	tree[l][PIVOTR] = pr;
	goto L10;
} /* end of ghtins */

/*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
GHTSEL - select nearest center from a generalized hyperplane tree

___Name____________Type______I/O____Description_________________________
   x[n][p]         float**   In     Data array
   n               int       In     # points in X
   p               int       In     # variables each datum
   w[p]            float*    In     Argument to distance function
   c[k][p]         float**   In     Coordinates of centers
   k               int       In     Number of centers
   robust          bool      In     Use Manhattan distance
   self            bool      In     Don't permit to select NEAR = Q
   q               int       In     Index into X of a point to query
   livec[k]        int*      In     > 0 if each cluster is in the live set
   livex           int       In     > 0 if query point is in the live set
   near            int*      Out    Index into C of the nearest center
   dist            float*    Out    Distance to the nearest neighbor
   tree[2*k][12]   int**     Both   The generalized hyperplane tree
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/
void ghtsel (float **x, int n, int p, float *w, float **c, int k,
             bool robust, bool self, int q, int *livec, int livex,
             int *near, float *dist, int **tree)
{
/* Constants */
	enum {POINTS, POINTL, POINTR, PIVOTL, PIVOTR, MARK, DIR, SCD,
	      LEAF = 1, BUCK0 = 2, BUCK9 = 11};
	static float BIG = 1.e36f;
	static float TWOAAS = 2.00001f;
/* Local variables */
	int i, j, l, fb, nb, pl, pr;
	float r, d2, dl, dr;
	union fltint {
		int fii;
		float fif;
	} crit_dist;
/* Function Body */
	r = robust ? *dist : sqrtf(*dist);
/* begin at root */
	l = 0;

/*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
     Come here when climbing.
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/
L10:
	if (-1 == tree[l][LEAF]) { /* inspect a leaf */
		for (j = BUCK0; j <= BUCK9; ++j) {
			i = tree[l][j];
			if (-1 == i) break; /* reached bottom of bucket */
			if (self && i == q) continue; /* don't select zero distance */
			if (livex <= 0 && livec[i] <= 0) continue; /* skip dead */
			d2 = ghtdsm (x[q], c[i], p, w, robust, *dist);
			if (d2 < *dist) { /* shorter distance? */
				*near = i;
				*dist = d2;
				r = robust ? d2 : sqrtf(d2);
			}
		}
		l = tree[l][POINTS]; /* back to stem node */
	} else {
		tree[l][MARK] = 0; /* clear mark in stem node */
		tree[l][DIR] = 0;
	}

/*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
        Come here when backing down.
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/
L50:
	if (-1 == l) return; /* is this the root node? */
/* measure as required */
	if (-1 == tree[l][DIR]) { /* known left branch */
		nb = POINTL;
		fb = POINTR;
		crit_dist.fii = tree[l][SCD];
	} else if (+1 == tree[l][DIR]) { /* known right branch */
		nb = POINTR;
		fb = POINTL;
		crit_dist.fii = tree[l][SCD];
	} else { /* unknown */
		pl = tree[l][PIVOTL];
		pr = tree[l][PIVOTR];
		dl = ghtdsm (x[q], c[pl], p, w, robust, BIG);
		dr = ghtdsm (x[q], c[pr], p, w, robust, BIG);
		if (!robust) {
			dl = sqrtf(dl);
			dr = sqrtf(dr);
		}
		crit_dist.fif = fabsf(dl - dr) / TWOAAS;
		tree[l][SCD] = crit_dist.fii; /* remember */
/* find near branch */
		if (dl < dr) {
			nb = POINTL;
			fb = POINTR;
			tree[l][DIR] = -1;
		} else {
			nb = POINTR;
			fb = POINTL;
			tree[l][DIR] = +1;
		}
	}
/*   explore the near branch */
	if (0 == tree[l][MARK]) { /* near branch unmarked? */
		tree[l][MARK] = 1;
		l = tree[l][nb];
		goto L10; /* and inspect the node */
	}
	if (r > crit_dist.fif && 1 == tree[l][MARK]) { /* consider far branch */
		tree[l][MARK] = 2; /* mark */
		l = tree[l][fb];
		goto L10; /* and inspect the node */
	}
/* backtrack */
	l = tree[l][POINTS];
	goto L50;
} /* end of ghtsel */
