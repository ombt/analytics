/***********************************************************************
t_round.c - a test program for CLUELA
By Andy Allinger, 2017, released to the public domain
This program may be used by any person for any purpose.
***********************************************************************/
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int **new_int_mtx (int m, int n); /* defined in array.c */
float **new_flt_mtx (int m, int n);
int del_int_mtx (int **b, int m);
int del_flt_mtx (float **x, int m);
int cluela (float **x, int **nx, int n, int p, float *w, float **c, int **nc, /* defined in cluela.c */
      int kmin, int *k, int kmax, int *z, int *pop, float *f, bool robust,
      bool sosdo, int *iwork, float *rwork, int **tree, float *u);

/* Main program */
int  main (void)
{
/* Constants */
#define KMAX 15
#define N 30000
#define NS 12
#define P 2
	const int kmin = 1;
	static float w[P] = { 1.f,1.f };
	const float twopi = 6.2831853f;
 /* Local variables */
	int i, j, k, l, z[N], iwork[4*N+KMAX], ifault, ferr, pop[KMAX];
	float r, u, f[KMAX], rnum, theta, rwork[2*N+KMAX];
	bool robust, sosdo;
	char ofile[32] = "round_output.csv";
	FILE *iou;
/* Allocate matrices */
	int **nc, **nx, **tree;
	float **c, **x;
	nc = new_int_mtx(N, KMAX);
	nx = new_int_mtx(N, P);
	tree = new_int_mtx(2*KMAX, NS);
	c = new_flt_mtx(N, KMAX);
	x = new_flt_mtx(N, P);
	if (!nc || !nx || !tree || !c || !x) goto L90;
/* initial values */
	for (i = 0; i < N; ++i) {
		for (j = 0; j < P; ++j) {
			nx[i][j] = 1;
		}
	}
	srand( (unsigned int)time(NULL));
	for (i = 0; i < N; ++i) { /* random points over unit circle */
		rnum = (float)rand() / (float)RAND_MAX;
		r = sqrtf(rnum); /* radius */
		rnum = (float)rand() / (float)RAND_MAX;
		theta = rnum * twopi; /* angle */
		x[i][0] = r * cosf(theta); /* Cartesian coordinates */
		x[i][1] = r * sinf(theta);
	}
	k = 6;
	robust = false;
	sosdo = true;
/* Call subroutine */
	ifault = cluela (x, nx, N, P, w, c, nc, kmin, &k, KMAX, z, pop,
	  f, robust, sosdo, iwork, rwork, tree, &u);
	printf("cluela returns #%d, made %d clusters with residual %f\n", ifault, k, u);
/* Write CSV file with Y-coordinates in different columns by cluster */
	iou = fopen(ofile, "w");
	if (NULL == iou) printf("t_round: trouble opening file %s\n", ofile);
	for (i = 0; i < N; ++i) {
		ferr = fprintf(iou, "%8.4f", x[i][0]);
		if (0 == ferr) printf("t_round: trouble writing X-coord\n");
/* one comma per cluster ID */
		for (l = 0; l < z[i]; ++l) {
			ferr = fprintf(iou, ",");
			if (0 == ferr) printf("t_round: trouble writing comma\n");
		}
		ferr = fprintf(iou, "%8.4f\n", x[i][1]);
		if (0 == ferr) printf("t_round: trouble writing Y-coord\n");
	}
/* Write the centroids in the far column */
	for (l = 0; l < k; ++l) {
		ferr = fprintf(iou, "%8.4f", c[l][0]);
		if (0 == ferr) printf("t_round: trouble writing X-coord\n");
		for (i = 0; i < k+1; ++i) {
			ferr = fprintf(iou, ",");
			if (0 == ferr) printf("t_round: trouble writing comma\n");
		}
		ferr = fprintf(iou, "%8.4f\n", c[l][1]);
		if (0 == ferr) printf("t_round: trouble writing Y-coord\n");
	}
/* Write the results for F */
	for (l = kmin; l <= KMAX; ++l) {
		ferr = fprintf(iou, "%d, %8.4f\n", l, f[l-kmin]);
		if (0 == ferr) printf("t_round: trouble writing F\n");
	}
	ferr = fclose(iou);
	if (0 != ferr) printf("t_round: trouble closing file.\n");
L90: /* release memory */
	if (nc) del_int_mtx(nc, N);
	if (nx) del_int_mtx(nx, N);
	if (tree) del_int_mtx(tree, 2*KMAX);
	if (c) del_flt_mtx(c, N);
	if (x) del_flt_mtx(x, N);
	return 0;
} /* end of main */
