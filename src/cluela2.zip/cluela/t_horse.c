/*======================================================================
test clustering on the horse colic data
by Andy Allinger, 2013-2017, public domain
This program may be used by any person for any purpose.
======================================================================*/
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int kmns (float **a, int m, int n, float **c, int k, /* defined in kmns.c */
          int *ic1, int *ic2, int *nc, float *an1, float *an2,
	     int *ncp, float *d, int *itran, int *live, int iter, float *wss);
int **new_int_mtx (int, int); /* defined in array.c */
float **new_flt_mtx (int, int);
char **new_ch_mtx (int, int);
int del_int_mtx (int **, int);
int del_flt_mtx (float **, int);
int del_ch_mtx (char **, int);
void avedev (float **, int **, int, int, int *, float *, float *); /* defined in stats.c */
void medmad (float **, int **, int, int, float *, float *, float *);
void jscode (int *jnam, int *nx, int *ind, int *jnd, int n); /* defined in prep.c */
void ordnal (float *x, int *nx, int *ind, int *jnd, int n);
int rscode (float **x, int **nx, int n, int p, float *w,
            int *cat, int o, float **s, int catmax, bool robust);
bool safdiv (float numer, float denom); /* defined in cluela.c */
bool almeq (float r, float s);
void shuffl (int *i, int n);
void dinit (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
           int k, bool robust, float *shortx, float *cumd, float *thresh);
int kclust (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
            int kmin, int *k, int kmax, int *z, int *pop, bool miss, bool robust, bool sosdo,
            float thresh, int *livec, int *livex, int *iperm, int **tree,
            float *shortc, float *shortx, float *work, float *u);
int cluela (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
            int kmin, int *k, int kmax, int *z, int *pop, float *f, bool robust,
            bool sosdo, int *iwork, float *rwork, int **tree, float *u);
int cluste (float **x, int **nx, int n, int p, float *w, float **c, int **nc, /* defined in cluste.c */
            int kmin, int *k, int kmax, int *z, int *pop, bool robust,
            bool sosdo, int *iwork, float *rwork, int **tree, float *u);
int neugas (float **, int, int, float **, int, int *, float *); /* defined in neugas.c */
int pca (float **x, int **nx, int n, int p, float *w, float *a, float *e, /* defined in pca.c */
         float **v, float *t, float *u, float **r, int m, int level);
int wcsvsp (float **, int, int *, FILE *); /* defined in dump.c */

int main (void)
{
/* Constants */
#define CATMAX 346 /* most categories any attribute */
#define HLEN 32    /* length of strings raw and fname */
#define KMIN 1     /* fewest clusters to make */
#define KMAX 20    /* most clusters to make */
#define KNG 200    /* centers in neural gas algorithm */
#define M 28       /* dimension to embed into */
#define N 368      /* Number of objects */
#define NS 12      /* node size of binary tree */
#define O 86       /* Attributes after recoding multi-attributes */
#define P 440      /* Attributes after recoding categoricals */
#define Q 3        /* Entries in attribute fields */
#define QN 1104    /* Q @ N */
#define TXTLEN 256 /* length of line of input */

	const int iter = 1000,  /* iterations of KMNS */
	          kk = 18,      /* clusters to make with KMNS trial */
	          level = 1;    /* what kind of PCA */
	static float big = 1e36f,   /* arbitrary large number */
	             xbogus = -9.f; /* arbitrary value for missing data */
	const float fone = 1.f,
	            ftwo = 2.f,
	            fthree = 3.f;
	const bool robust = false;
/* Local variables */
	int h, i, j, k, l, z[N], jng[KNG], ncp[KMAX], zkc[N], pop[KMAX],
      hbeg, ferr, colt[N], live[KMAX], iperm[QN], jperm[QN], itran[KMAX],
      na[P], ll, iwork[4*N+KMAX], hosptl[N], gnosis[QN], cplen, ifault;
	float x0[N], an1[KMAX], an2[KMAX], dng[KNG], wss[KMAX], a[P], e[P], f[KMAX],
	  t[P], u, ubest, rwork[2*N+KMAX], thresh;
	bool miss, sosdo;
	FILE *iou;
	char raw[HLEN], empty[HLEN], text[TXTLEN];
	char *sptr;

	char fname[HLEN] = "horse-colic.both";
/*======================================================================
Horse colic data
From the University of California at Irvine Machine Learning repository

Creators: Mary McLeish & Matt Cecile
      Department of Computer Science
          University of Guelph
          Guelph, Ontario, Canada N1G 2W1
          mdmcleish@water.waterloo.edu

Classes:
  None.  Approach this data as a pure clustering problem.

Attributes are:

___O___Attribute__________Type____________#___Values_________________
   0   surgery            Boolean         2   1 = yes
                                              2 = no

   1   age                Categorical     2   1 = adult
                                              9 = young     ! 9?

   2   hospital number    Categorical   346   ID number assigned to horse

If the horse lives, then this might be considered a categorical
variable.  Since a horse only dies once, for horses in the groups
Died and Was Euthanized, this is a contra-categorical variable, since
the presence of a horse in one of these groups means that no other
instances of this horse may be present.  The proper interpretation of
this variable may be some complex, asymmetric relationship.

   3   rectal temp        Continuous          [degrees Celsius]

   4   pulse              Continuous          [beats per minute]

   5   respiratory rate   Continuous

   6   extremities temp   Ordinal             1 = Normal
                                              2 = Warm
                                              3 = Cool
                                              4 = Cold
                                                           Wrong order!

   7   peripheral pulse   Ordinal             1 = normal
                                              2 = increased
                                              3 = reduced
                                              4 = absent
                                                           Wrong order!

   8   mucous membranes   Categorical     6   1 = normal pink
                                              2 = bright pink
                                              3 = pale pink
                                              4 = pale cyanotic
                                              5 = bright red / injected
                                              6 = dark cyanotic

   9   capillary refill   Categorical     3   1 = < 3 seconds
                                              2 = >= 3 seconds
                                              3:  undocumented!

  10   pain               Continuous          1 = alert, no pain
                                              2 = depressed
                                              3 = intermittent mild pain
                                              4 = intermittent severe pain
                                              5 = continuous severe pain

     The file 'horse-colic.names' says: "should NOT be treated as a ordered
or discrete variable!"  Obey this instruction and treat pain as continuous.

  11   peristalsis        Ordinal             1 = hypermotile
                                              2 = normal
                                              3 = hypomotile
                                              4 = absent

  12   abdom distension   Ordinal             1 = none
                                              2 = slight
                                              3 = moderate
                                              4 = severe

  13   nasogastric tube   Ordinal             1 = none
                                              2 = slight
                                              3 = significant

  14   naso. reflux       Ordinal             1 = none
                                              2 = > 1 liter
                                              3 = < 1 liter
                                                           Wrong order!

  15   reflux PH          Continuous          0...14

  16   rectal feces       Ordinal             1 = normal
                                              2 = increased
                                              3 = decreased
                                              4 = absent
                                                           Wrong order!

  17   abdomen            Categorical     5   1 = normal
                                              2 = other
                                              3 = firm feces large intestine
                                              4 = distended small intestine
                                              5 = distended large intestine

  18   packed cell vol.   Continuous          red cells by volume in blood

  19   total protein      Continous           [gms/dL]

  20   abdominocentesis   Categorical     3   1 = clear
                                              2 = cloudy
                                              3 = serosanguinous

  21   abdom. protein     Continuous          [gms/dL]

  22   outcome            Categorical     3   1 = lived
                                              2 = died
                                              3 = was euthanized

  23   surgical lesion?   Boolean         2   1 = Yes
                                              2 = No

  24   type of lesion     Multi          62
 ...
  85

      Three columns contain either 00000 or one of 62 distinct
numeric codes for a diagnosis.

       cp_data            Boolean         2   1 = Yes
                                              2 = No

      This column is irrelevant and shall be omitted.

======================================================================*/

/* info above is summarized thus: */
	static int cat[O] = { 2,2,346,0,0,0,0,0,6,3,0,0,0,0,0,0,0,5,0,0,3,0,
	  3,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
	static bool ordreq[O] = { false,false,false,false,false,false,
	  true,true,false,false,false,true,true,true,true,false,
	  true,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false };
	static bool stdreq[O] = { false,false,false,true,true,true,
	  false,false,false,false,true,false,false,false,false,
	  true,false,false,true,true,false,true,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false,false,false,
	  false,false,false,false,false,false,false };
	static float w[P];
	static int nx0[QN];
/* set initial values */
	for (j = 0; j < O; ++j) w[j] = 1.f;
	for (j = O; j < P; ++j) w[j] = 0.f; /* just to be sure */
	for (j = 0; j < P; ++j) nx0[j] = 1; /* no missing diagnoses */
	for (i = 0; i < HLEN; ++i) empty[i] = '\0';
/* allocate arrays */
	int **nx, **nc, **tree;
	nx = new_int_mtx (N, P);
	nc = new_int_mtx (KMAX, P);
	tree = new_int_mtx (2*KMAX, NS);
	float **x, **c, **r, **s, **v, **cng;
	x = new_flt_mtx (N, P);
	c = new_flt_mtx (KMAX, P);
	r = new_flt_mtx (N, M);
	s = new_flt_mtx (CATMAX, CATMAX-1);
	v = new_flt_mtx (P, P);
	cng = new_flt_mtx (KNG, M);
	if (!nx || !nc || !tree || !x || !c || !r || !s || !v || !cng) {
		printf("thorse:  trouble allocating memory!\n");
		goto L90;
	}
	srand((unsigned int) time(NULL));
/* open input file */
	iou = fopen(fname, "r");
	if (NULL == iou) {
		printf("trouble opening file: %s \n", fname);
		return -1;
	}
/*  Read input data */
	for (i = 0; i < N; ++i) {
		sptr = fgets(text, TXTLEN, iou);
		if (NULL == sptr) printf("trouble reading from file, line %d \n", i+1);
		ll = (int)strlen(text);
		hbeg = 0;
		l = 0;
		j = 0;
		for (h = 0; h < ll; ++h) {
			if (' ' == text[h]) { /* split on spaces */
				++l;
				strncpy(raw, empty, HLEN);
				cplen = h - hbeg;
				if (cplen > HLEN) cplen = HLEN;
				strncpy (raw, &text[hbeg], cplen);
			} else if (h == ll-1) {
				++l;
				strncpy(raw, empty, HLEN);
				cplen = h - hbeg + 1;
				if (cplen > HLEN) cplen = HLEN;
				strncpy(raw, &text[hbeg], cplen);
			} else {
				continue;
			}
			if (2 == l) { /* relabel young/adult column */
				nx[i][j] = 1; /* nothing missing this column */
				++j;
				ferr = sscanf(raw, " %d", &colt[i]);
				if (0 == ferr) printf("trouble reading young/adult at line %d\n", i);
			} else if (3 == l) { /* relabel ID # */
				nx[i][j] = 1; /* nothing missing */
				++j;
				ferr = sscanf(raw, " %d", &hosptl[i]);
				if (0 == ferr) printf("error reading ID # line %d\n", i);
			} else if (25 == l) {
				ferr = sscanf(raw, " %d", &gnosis[3*i]);
				if (0 == ferr) printf("error reading attrib1 object %d\n", i);
			} else if (26 == l) {
				ferr = sscanf(raw, " %d", &gnosis[3*i+1]);
				if (0 == ferr) printf("error reading attrib2 object %d\n", i);
			} else if (27 == l) {
				ferr = sscanf(raw, " %d", &gnosis[3*i+2]);
				if (0 == ferr) printf("error reading attrib3 object %d\n", i);
			} else if (28 == l) { /* ignore cp_data */
				;
			} else if (NULL == strstr(raw, "?")) { /* data present? */
				ferr = sscanf(raw, " %f", &x[i][j]);
				if (0 == ferr) printf("error reading X, i: %d l: %d\n", i, l);
				nx[i][j] = 1;
				++j;
			} else { /* missing */
				x[i][j] = xbogus;
				nx[i][j] = 0;
				++j;
			}
			hbeg = h + 1;
		}
	}
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing file %s\n", fname);

/*======================================================================
        preprocess data
======================================================================*/
/* relabel the young / adult variable */
	jscode (colt, nx0, iperm, jperm, N);
	for (i = 0; i < N; ++i) x[i][1] = (float) colt[i];
/*  relabel case ID's */
	jscode (hosptl, nx0, iperm, jperm, N);
	for (i = 0; i < N; ++i) x[i][2] = (float) hosptl[i];
/*  standardize */
	if (robust) {
		medmad (x, nx, N, O, x0, a, t);
	} else {
		avedev (x, nx, N, O, na, a, t);
	}
	for (l = 0; l < O; ++l) {
		if (stdreq[l]) {
			if (safdiv (fone, t[l])) {
				t[l] = 1.f / t[l];
			} else {
				t[l] = 0.f;
			}
			for (i = 0; i < N; ++i) x[i][l] = (x[i][l] - a[l]) * t[l];
		}
	}
/* fix wrong ordered ordinals */
	for (i = 0; i < N; ++i) {
		if (almeq(x[i][5], fone)) { /* put subjective temperature in order */
			x[i][5] = 2.f;
		} else if (almeq (x[i][5], ftwo)) {
			x[i][5] = 1.f;
		}
		if (almeq (x[i][6], fone)) { /* put subjective pulse in order */
			x[i][6] = 2.f;
		} else if (almeq (x[i][6], ftwo)) {
			x[i][6] = 1.f;
		}
		if (almeq (x[i][13], ftwo)) { /* put reflux in order */
			x[i][13] = 3.f;
		} else if (almeq (x[i][13], fthree)) {
			x[i][13] = 2.f;
		}
		if (almeq (x[i][15], fone)) { /* put feces in order */
			x[i][15] = 2.f;
		} else if (almeq (x[i][15], ftwo)) {
			x[i][15] = 1.f;
		}
	}
/* rescale ordinals */
	for (l = 0; l < O; ++l) {
		if (ordreq[l]) {
			for (i = 0; i < N; ++i) { /* pack */
				x0[i] = x[i][l];
				nx0[i] = nx[i][l];
			}
			ordnal (x0, nx0, iperm, jperm, N);
			for (i = 0; i < N; ++i) x[i][l] = x0[i]; /* unpack */
		}
	}
/* convert diagnosis codes to small consecutive integers */
	for (h = 0; h < QN; ++h) nx0[h] = 1; /* nothing missing */
	jscode (gnosis, nx0, iperm, jperm, QN);
	for (h = 0; h < QN; ++h) --gnosis[h]; /* zero is null attribute! */
/* recode the multi-attribute */
	for (i = 0; i < N; ++i) {
		for (j = 24; j < O; ++j) { /* clear */
			x[i][j] = 0.f;
			nx[i][j] = 1;
		}
	}
	for (i = 0; i < N; ++i) {
		for (h = 0; h < Q; ++h) {
			if (gnosis[Q*i+h] != 0) {
				j = 23 + gnosis[Q*i+h];
				x[i][j] = 1.f;
			}
		}
	}
/* recode categoricals with corresponding column of simplex */
	ifault = rscode (x, nx, N, P, w, cat, O, s, CATMAX, robust);
	if (ifault != 0) printf("rscode: error # %d\n", ifault);

/*======================================================================
 call CLUELA on the full problem
======================================================================*/
	printf("Original problem:\n");
	k = 3;
	sosdo = true;
	ifault = cluela (x, nx, N, P, w, c, nc, KMIN, &k, KMAX, z, pop,
	  f, robust, sosdo, iwork, rwork, tree, &u);
	 printf("cluela returns #%d, made %d clusters with residual %f\n", ifault, k, (double)u);
/* write F values */
	strncpy(fname, "horse_fvals_full.csv", HLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("thorse: trouble opening %s \n", fname);
	for (l = KMIN; l <= KMAX; ++l) {
		ifault = fprintf(iou, "%5i, %9.3g\n", l, (double)f[l-KMIN]);
		if (0 == ifault) printf("thorse: trouble writing F stats\n");
	}
	ferr = fclose(iou);
	if (0 != ferr) printf("thorse: trouble closing file %s \n", fname);
	k = 3;
	miss = true;
	dinit (x, nx, N, P, w, c, nc, k, robust, rwork, &rwork[N], &thresh);
	ifault = kclust (x, nx, N, P, w, c, nc, KMIN, &k, KMAX, zkc, pop,
	  miss, robust, sosdo, thresh, iwork, &iwork[KMAX], &iwork[KMAX+N],
	  tree, rwork, &rwork[KMAX], &rwork[KMAX+N], &u);
	printf("kclust returns #%d, made %d clusters with residual %f\n", ifault, k, (double)u);

/*======================================================================
project to lower dimension
======================================================================*/
	ifault = pca (x, nx, N, P, w, a, e, v, t, rwork, r, M, level);
	if (0 != ifault) printf("pca: error #%d\n", ifault);
/* Scatter plot of KCLUST result */
	strncpy(fname, "horse_clusters_kclust.csv", HLEN);
	iou = fopen (fname, "w");
	if (NULL == iou) printf("thorse: trouble opening %s\n", fname);
	ifault = wcsvsp (r, N, zkc, iou);
	if (0 != ifault) printf("wcsvsp: error#%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing %s\n", fname);
/* There is no longer any missing data.
   Remember that dimension is now M. */
	for (i = 0; i < N; ++i) {
		for (j = 0; j < M ; ++j) {
			nx[i][j] = 1;
		}
	}
/* remember to change W */
	for (j = 0; j < M; ++j) w[j] = 1.f;
	k = kk;
/* Call KMNS on projected data.  Remember to initalize centers. */
	printf("\nProjected problem:\n");
	ubest = big;
	for (h = 0; h < 10; ++h) {
		dinit (r, nx, N, M, w, c, nc, k, robust, rwork, &rwork[N], &thresh);
		ifault = kmns (r, N, M, c, k, z, iperm, pop, an1, an2, ncp,
		  rwork, itran, live, iter, wss);
		u = 0.f;
/* combine per-cluster residuals */
		for (l = 0; l < k; ++l) u += wss[l];
		if (0 == ifault) {
			ubest = (ubest < u) ? ubest : u;
		} else {
			printf("kmns: error#%d\n", ifault);
		}
	}
	printf("kmns returns #%d, made %d clusters with residual %f\n", ifault, k, (double)ubest);
/* Call CLUELA on the projected data, seeking low residual */
	k = kk;
	sosdo = true;
	ifault = cluela (r, nx, N, M, w, c, nc, kk, &k, kk, z, pop, f,
	  robust, sosdo, iwork, rwork, tree, &u);
	printf("cluela returns #%d, made %d clusters with residual %f\n", ifault, k, (double)u);
/* call alternate interface, with speedy options and initial centers */
	sosdo = false;
	ubest = big;
	for (h = 0; h < 10; ++h) {
		k = kk;
		ifault = cluste (r, nx, N, M, w, c, nc, KMIN, &k, KMAX, z, pop,
		  robust, sosdo, iwork, rwork, tree, &u);
		if (ifault == 0) {
			ubest = (ubest < u) ? ubest : u;
		} else {
			printf("cluste: error#%d\n", ifault);
		}
	}
	printf("cluste returns #%d, made %d clusters with residual %f\n", ifault, k, (double)u);
/* Call the neural gas routine */
	shuffl (iwork, N); /* choose random centers */
	for (l = 0; l < KNG; ++l) {
		i = iwork[l] - 1;
		for (j = 0; j < M; ++j) cng[l][j] = r[i][j];
	}
	neugas(r, N, M, cng, KNG, jng, dng);
	printf("neugas returns\n");
	strncpy(fname, "horse_ng_centers.csv", HLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("thorse: trouble opening %s\n", fname);
	for (l = 0; l < KNG; ++l) {
		ifault = fprintf(iou, "%9.3g,%9.3g\n", (double)cng[l][0], (double)cng[l][1]);
		if (0 == ifault) printf("thorse: trouble writing NG data\n");
	}
	ferr = fclose(iou);
	if (0 != ferr) printf("thorse: trouble closing file %s\n", fname);
L90: /* Release memory */
	if (nx) del_int_mtx(nx, N);
	if (nc) del_int_mtx(nc, KMAX);
	if (tree) del_int_mtx(tree, 2*KMAX);
	if (x) del_flt_mtx(x, N);
	if (c) del_flt_mtx(c, KMAX);
	if (r) del_flt_mtx(r, N);
	if (s) del_flt_mtx(s, CATMAX);
	if (v) del_flt_mtx(v, P);
	if (cng) del_flt_mtx(cng, KNG);
	printf("program complete\n");
	return 0;
} /* end of main */
