/************************************************************************
neugas.c - neural gas, a data clustering algorithm
by Andy Allinger, 2013-2017, released to the public domain
This program may be used by any person for any purpose.

Refer to:
     Thomas Martinetz and Klaus Schulten
     A "Neural-Gas" Network Learns Topologies
     in Artificial Neural Networks, Ed. T. Kohonen, K. Makisara,
     O. Simula, and J. Kangas.  Holland: Elsevier, 1991.

Also the description by Bernd Fritzke at:
     www.demogng.de/JavaPaper/node16.html

This routine follows Fritzke and omits the topology.

___Name______Type______In/Out____Description____________________________
   x[n][p]   float**   In        Data Matrix
   n         int       In        Number of objects
   p         int       In        Measurements per object
   c[k][p]   float**   Both      Cluster centers
   k         int       In        Number of clusters
   ind[k]    int*      Neither   Index array
   d[k]      float*    Neither   Distances to each center
***********************************************************************/
#include <stdlib.h>
#include <math.h>
int qsortr (float *, int *, int);

void neugas (float **x, int n, int p, float **c, int k, int *ind, float *d)
{
/* constants */
	static float lami = 10.f; /* range of adjustment, initial */
	static float lamf = 0.01f; /* range of adjustment, final */
	static float epsi = 0.3f; /* adjustment, initial */
	static float epsf = 0.005f; /* adjustment, final */
	static int tau = 40000; /* iterations */
/* Local variables */
	int h, i, j, l;
	float r, y;
	float eps, tot, efact, lfact, lambda;
/* Function Body */
	lambda = lami;
	eps = epsi;
	lfact = powf( lamf / lami, 1.f / (float) (tau - 1) );
	efact = powf( epsf / epsi, 1.f / (float) (tau - 1) );

/************************************************************************
                main loop
************************************************************************/
	for (h = 0; h < tau; ++h) {
/* choose a datum at random */
		r = (float) rand() / (float) (RAND_MAX);
		i = (int) (r * n);
		if (i > (n - 1)) i = n - 1;
/* find distance to each center */
		for (l = 0; l < k; ++l) {
			tot = 0.f;
			for (j = 0; j < p; ++j) {
				r = x[i][j] - c[l][j];
				tot += r * r;
			}
			d[l] = tot;
		}
/* sort distances */
		qsortr (d, ind, k);
		for (l = 0; l < k; ++l) d[ind[l]-1] = (float) (l); /* rank */
/* adapt the cluster centers */
		for (l = 0; l < k; ++l) {
			y = eps * expf(-d[l] / lambda);
			for (j = 0; j < p; ++j) c[l][j] += y * (x[i][j] - c[l][j]);
		}
/* adjust parameters */
		lambda *= lfact;
		eps *= efact;
	}
	return;
} /* end of neugas */
