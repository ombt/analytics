/*======================================================================
test clustering on the credit approval data
by Andy Allinger, 2017, public domain
This program may be used by any person for any purpose.
======================================================================*/
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int **new_int_mtx (int, int); /* defined in array.c */
float **new_flt_mtx (int, int);
char **new_ch_mtx (int, int);
int del_int_mtx (int **, int);
int del_flt_mtx (float **, int);
int del_ch_mtx (char **, int);
int ireid (char **h, int *id, int *nx, int *ind, int *jnd, int n, int h_len, char *hwork);
int rscode (float **x, int **nx, int n, int p, float *w,
            int *cat, int o, float **s, int catmax, bool robust);
void dinit (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
           int k, bool robust, float *shortx, float *cumd, float *thresh);
int cluela (float **x, int **nx, int n, int p, float *w, float **c, int **nc,
            int kmin, int *k, int kmax, int *z, int *pop, float *f, bool robust,
            bool sosdo, int *iwork, float *rwork, int **tree, float *u);
float arind (int *y, int *z, int n, int g, int k, float **m, float *a, float *b); /* defined in valid.c */
float vinfo (int *y, int *z, int n, int g, int k, float **m, float *a, float *b);
int pca (float **x, int **nx, int n, int p, float *w, float *a, float *e, /* defined in pca.c */
         float **v, float *t, float *u, float **r, int m, int level);
int wcsvsp (float **, int, int *, FILE *); /* defined in dump.c */

/* Main program */
int main (void)
{
/* Constants */
#define CATMAX 14  /* most categories any attribute */
#define FNLEN 32   /* length of a file name */
#define G 2        /* # correct classes */
#define HLEN 32    /* length of a string */
#define KMIN 1     /* fewest clusters to make */
#define KMAX 20    /* most clusters to make */
#define LBLLEN 1   /* length of the class label */
#define M 2        /* dimensions to embed into */
#define N 690      /* number of objects */
#define NO 10350   /* N @ O */
#define NS 12      /* node size of binary tree */
#define O 15       /* input attributes */
#define P 38       /* attributes after encoding */
#define SYMLEN 2   /* length of symbol strings */
#define TXTLEN 256 /* length of line of input file */

	const float xbogus = -9.f; /* arbitrary value for missing data */
	const bool robust = false, /* Use L1 statistics? */
	           sosdo = false; /* optimize sum-of-square distace objective? */

/* Local variables */
	int i, j, k, l, y[N], z[N], ll, nx0[N], pop[KMAX], jbeg, ferr,
	  cplen, level, iperm[N], jperm[N], iwork[4*N+KMAX], ifault;
	float a[P], e[P], f[KMAX], t[P], u, rwork[2*N+KMAX],
	  aval[G], bval[KMAX];
	float accvi = -1.f,
	      accari = -1.f;
	char ch1[LBLLEN], hwork[SYMLEN], empty[HLEN], raw[HLEN], text[TXTLEN];
	char *sptr;
	FILE *iou;

/* Allocate matrices */
	int **nc, **nx, **tree;
	float **c, **mval, **r, **s, **v, **x;
	char **clslbl, **symbol;
	nc = new_int_mtx (KMAX, P);
	nx = new_int_mtx (N, P);
	tree = new_int_mtx (2*KMAX, NS);
	c = new_flt_mtx (KMAX, P);
	mval = new_flt_mtx (G, KMAX);
	r = new_flt_mtx (N, M);
	s = new_flt_mtx (CATMAX, CATMAX-1);
	v = new_flt_mtx (P, P);
	x = new_flt_mtx (N, P);
	clslbl = new_ch_mtx (N, LBLLEN);
	symbol = new_ch_mtx (N*O, SYMLEN);
	if (!nc || !nx || !tree || !c || !mval || !r || !s || !v || !x ||
	  !clslbl || !symbol) goto L90;

	static char fname[FNLEN] = "crx.data";
/*======================================================================
Credit card application data
From the University of California at Irvine Machine Learning repository

Reference:
     Ross Quinlan
     "Simplifying decision trees"
     Int J Man-Machine Studies v.27, pp.221-234
     Dec 1987

This data was provided by an anonymous donor.  The attributes have been
changed to arbitrary values.

Classes are:
   +, -

Attributes are:

___Attribute___Type___________#___Values_______________________________
   1          Categorical    2   b, a
   2          Continuous
   3          Continuous
   4          Categorical    4   u, y, l, t
   5          Categorical    3   g, p, gg
   6          Categorical   14   c, d, cc, i, j, k, m, r, q, w, x, e, aa, ff
   7          Categorical    9   v, h, bb, j, n, z, dd, ff, o
   8          Continuous
   9          Boolean        2   t, f
  10          Boolean        2   t, f
  11          Continuous
  12          Boolean        2   t, f
  13          Categorical    3   g, p, s
  14          Continuous
  15          Continuous
======================================================================*/

/* Info above is summarized thus: */
	static int cat[O] = { 2,0,0,4,3,14,9,0,2,2,0,2,3,0,0 };
/* Weights chosen to shrink large continuous values */
	static float w[P] = { 1.f,.08f,.2f,1.f,1.f,1.f,1.f,.3f,1.f,1.f,.2f,1.f,
	  1.f,.006f,2e-4f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,
	  0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f };
/* bogus initial value */
	for (i = 0; i < NO; ++i) {
		for (j = 0; j < SYMLEN; ++j) {
			symbol[i][j] = '$';
		}
	}
	for (i = 0; i < HLEN; ++i) empty[i] = '\0';
/* initialize random number generator */
	srand( (unsigned int)time(NULL));
/* open input file */
	iou = fopen(fname, "r");
	if (NULL == iou) printf("tcrx: trouble opening input file\n");
/* read in data */
	for (i = 0; i < N; ++i) {
		sptr = fgets(text, TXTLEN, iou);
		if (NULL == sptr) printf("trouble reading from file, line %d\n", i);
		ll = (int) strlen(text);
		jbeg = 0;
		l = 0;
/* split on commas */
		for (j = 0; j < ll; ++j) {
			if (',' == text[j]) {
				++l;
				strncpy(raw, empty, HLEN);
				cplen = j - jbeg;
				if (cplen > HLEN) cplen = HLEN;
				strncpy(raw, &text[jbeg], cplen);
			} else if (j == ll-1) {
				++l;
				strncpy(raw, empty, HLEN);
				cplen = j - jbeg + 1;
				if (cplen > HLEN) cplen = HLEN;
				strncpy(raw, &text[jbeg], cplen);
			} else {
				continue;
			}
			if (l > O+1) printf("trouble reading l > O+1\n");
			if (16 == l) { /* answer key */
				clslbl[i][0] = raw[0];
			} else if (NULL == strstr(raw, "?")) { /* non-missing */
				if (0 == cat[l-1]) { /* numerical? */
					ferr = sscanf(raw, " %f", &x[i][l-1]);
					if (0 == ferr) printf("error scanning X, i: %d, l: %d, string: %s \n", i, l, raw);
				} else {
					strncpy(symbol[(l-1)*N+i], raw, SYMLEN);
				}
				nx[i][l-1] = 1;
			} else { /* missing */
				x[i][l-1] = xbogus;
				nx[i][l-1] = 0;
			}
			jbeg = j + 1;
		}
	}
	ifault = fclose(iou);
	if (0 != ifault) printf("trouble closing file %s\n", fname);
/* preprocess input */
	for (l = 0; l < O; ++l) { /* convert text labels to integers */
		if (cat[l] > 0) {
			for (i = 0; i < N; ++i) nx0[i] = nx[i][l];
			ifault = ireid (&symbol[l*N], z, nx0, iperm, jperm, N, SYMLEN, hwork);
			if (ifault != 0) printf("ireid: error#%d\n", ifault);
			for (i = 0; i < N; ++i) x[i][l] = (float) z[i];
		}
	}
/* recode categoricals with corresponding column of simplex */
	ifault = rscode (x, nx, N, P, w, cat, O, s, CATMAX, robust);
	if (ifault != 0) printf("rscode: error #%d\n", ifault);
/* relabel class ID's */
	for (i = 0; i < N; ++i) nx0[i] = 1;
	ifault = ireid (clslbl, y, nx0, iperm, jperm, N, LBLLEN, ch1);
	if (ifault != 0) printf("ireid on class, error #%d\n", ifault);
/* call the subroutine */
	k = 3;
	ifault = cluela (x, nx, N, P, w, c, nc, KMIN, &k, KMAX,
	  z, pop, f, robust, sosdo, iwork, rwork, tree, &u);
	printf("cluela returns #%d, made %d clusters\n", ifault, k);
/* find accuracy */
	if (ifault == 0) {
		accari = arind (y, z, N, G, k, mval, aval, bval); /* adjusted Rand index */
		accvi = vinfo (y, z, N, G, k, mval, aval, bval); /* variation of information */
	}
/* project to 2-D */
	level = 0;
	ifault = pca (x, nx, N, P, w, a, e, v, t, rwork, r, M, level);
	if (ifault != 0) printf("pca: error#%d\n", ifault);
/* Write CSV file with coordinates in different columns by cluster */
	strncpy(fname, "crx_clusters.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("tcrx: trouble opening %s\n", fname);
	ifault = wcsvsp (r, N, z, iou);
	if (ifault != 0) printf("wcsvsp: error#%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing file %s\n", fname);
/* Write CSV file with coordinates in different columns by class */
	strncpy(fname, "crx_classes.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("tcrx: trouble opening %s\n", fname);
	ifault = wcsvsp (r, N, y, iou);
	if (0 != ifault) printf("wcsvsp: error#%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing file %s\n", fname);
/* Scatter plot for Chebyshev PCA */
	level = -1;
	ifault = pca (x, nx, N, P, w, a, e, v, t, rwork, r, M, level);
	if (ifault != 0) printf("pca: error#%d\n", ifault);
	strncpy(fname, "crx_-1.csv", FNLEN);
	iou = fopen(fname, "w");
	if (ifault != 0) printf("tcrx: trouble opening %s\n", fname);
	ifault = wcsvsp (r, N, y, iou);
	if (ifault != 0) printf("wcsvsp: error#%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing file %s\n", fname);
/* Scatter plot for Manhattan PCA */
	level = 1;
	ifault = pca (x, nx, N, P, w, a, e, v, t, rwork, r, M, level);
	if (ifault != 0) printf("pca: error#%d\n", ifault);
	strncpy(fname, "crx_1.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("tcrx: trouble opening %s\n", fname);
	ifault = wcsvsp (r, N, y, iou);
	if (ifault != 0) printf("wcsvsp: error#%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing file %s\n", fname);
/* Scatter plot for comedian */
	level = 2;
	ifault = pca (x, nx, N, P, w, a, e, v, t, rwork, r, M, level);
	if (ifault != 0) printf("pca: error#%d\n", ifault);
	strncpy(fname, "crx_2.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("tcrx: trouble opening %s\n", fname);
	ifault = wcsvsp (r, N, y, iou);
	if (ifault != 0) printf("wcsvsp: error #%d\n", ifault);
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing file %s\n", fname);
/* write F values */
	strncpy(fname, "crx_fvals.csv", FNLEN);
	iou = fopen(fname, "w");
	if (NULL == iou) printf("tcrx: trouble opening %s\n", fname);
	for (l = KMIN; l <= KMAX; ++l) {
		fprintf(iou, "%5i, %9.3g", l, f[l-KMIN]);
		if (ifault != 0) printf("tcrx: trouble writing F stats\n");
	}
	ferr = fclose(iou);
	if (0 != ferr) printf("trouble closing file %s\n", fname);
	printf("Returned residual:  %f\n", u);
	printf("Adjusted Rand Index:  %f\n", accari);
	printf("Variation of Information:  %f\n", accvi);
L90: /* release memory */
	if (nc) del_int_mtx (nc, KMAX);
	if (nx) del_int_mtx (nx, N);
	if (tree) del_int_mtx (tree, 2*KMAX);
	if (c) del_flt_mtx (c, KMAX);
	if (mval) del_flt_mtx (mval, G);
	if (r) del_flt_mtx (r, N);
	if (s) del_flt_mtx (s, CATMAX);
	if (v) del_flt_mtx (v, P);
	if (x) del_flt_mtx (x, N);
	if (clslbl) del_ch_mtx (clslbl, N);
	if (symbol) del_ch_mtx (symbol, N*O);
	printf("program complete\n");
	return 0;
} /* end of main */
