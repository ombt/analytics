/* add.c - compensated addition by the Kahan algorithm */
void add (float *x, int n, float *r)
{
	int k;
	double s, c, y, t;
	s = 0.;
	c = 0.;
	for (k = 0; k < n; ++k) {
		y = x[k] - c;
		t = s + y;
		c = (t - s) - y;
		s = t;
	}
	*r = (float) s;
	return;
} /* End of add */
